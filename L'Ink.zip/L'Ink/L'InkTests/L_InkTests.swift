//
//  L_InkTests.swift
//  L'InkTests
//
//  Created by Daniela on 4/28/25.
//

import Testing
@testable import L_Ink

struct L_InkTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
